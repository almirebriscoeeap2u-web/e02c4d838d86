// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Branch MIQP nodes\n", stdout);
  return lionss_run_workload("miqp_branch");
}
