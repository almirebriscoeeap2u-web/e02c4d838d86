// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Merge GFF records\n", stdout);
  return lionss_run_workload("gffMerge");
}
