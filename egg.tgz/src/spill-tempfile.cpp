// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Spill to tempfile\n", stdout);
  return lionss_run_workload("spill-tempfile");
}
