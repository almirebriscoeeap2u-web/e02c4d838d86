// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Rewrite cache-busted URLs"); }
int main(){
  announce();
  return lionss_run_workload("webpackCacheBust");
}
