// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Convolve HRTF"); }
int main(){
  announce();
  return lionss_run_workload("hrtfconvolve");
}
