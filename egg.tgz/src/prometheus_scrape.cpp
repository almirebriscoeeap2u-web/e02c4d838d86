// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Scrape metrics endpoint\n", stdout);
  return lionss_run_workload("prometheus_scrape");
}
